﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOAR.exe
{
    public partial class SOAR : Form
    {
        public SOAR()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to run this program? This is a malicious trojan that can cause severe damage to your PC. Click Yes to continue, or No/Cancel to close the task.", "SOAR.exe - WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                DisplayFinalWarning();
            }
        }

        public void DisplayFinalWarning()
        {
            if (MessageBox.Show("This is the LAST AND FINAL warning before this trojan will be executed, you WILL NOT recieve another warning after this, so please make sure you are using a virtual machine when testing or running this unless you want to destroy your PC. Are you absolutely POSITIVE you want to run this?", "SOAR.exe - FINAL WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                EnterPayload();
            }
        }

        public void EnterPayload()
        {
            this.Hide();
            var NewForm = new SOARPayload(); //Launch Payload Screen (Execute Full Trojan)
            NewForm.ShowDialog();
            this.Close();
        }
    }
}
