﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.IO;

namespace SOAR.exe
{
    public partial class SOARSound : Form
    {
        private SoundPlayer _soundplayer;
        string SoundFile = @"C:\Windows\Media\Windows Critical Stop.wav";
        public SOARSound()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            if (File.Exists(SoundFile))
            {
                _soundplayer = new SoundPlayer(@"C:\Windows\Media\Windows Critical Stop.wav");
            }
        }

        private void SOARSound_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void SOARSound_Load(object sender, EventArgs e)
        {
            tmr1.Start();
            tmrNextPayload.Start();
        }

        private void tmr1_Tick(object sender, EventArgs e)
        {
            tmr1.Stop();
            _soundplayer.Play();
            tmr1.Start();
        }

        private void tmrNextPayload_Tick(object sender, EventArgs e)
        {
            tmrNextPayload.Stop();
            var NewForm = new SOARLast();
            NewForm.ShowDialog();
            tmrNextPayload.Start();
        }
    }
}
